# change_color

This is an example of how to use a FlareController to change the color of a shape defined in your Flare file programatically. Take a look at the correspding Flare project here:
https://www.2dimensions.com/a/castor/files/flare/change-color-example
