package com.example.penguin_dance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
