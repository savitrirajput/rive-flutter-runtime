class TransformSpace {
  static const int local = 0;
  static const int world = 1;
}
