// ignore: one_member_abstracts
abstract class Interpolator {
  double getEasedMix(double mix);
}
